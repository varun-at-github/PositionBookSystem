1) 	package: com.jpmc.position.manager
	Class: PositionManager
	Description: Main Class which trigger the PositionBookSystem. It is responsible for following events -
		- Process trade and update Position Book
		- Trigger the trade event (as of now, input is passed as Space delimited String in Main method). 

2)	package: com.jpmc.position.action
	interface: TradeAction
	Description: Interface to process Trade based on Action - BUY, SELL and CANCEL.

3) 	package: com.jpmc.position.action.impl
	Class1: BuyTradeAction
	Description: Implementation class for BUY Trade action. This class is responsible for Buy a Security 
	and processing the trade.
	
	Class2: SellTradeAction
	Description: Implementation class for SELL Trade action. This class is responsible for Selling a Security 
	and processing the trade.
	
	Class3: CancelTradeAction
	Description: Implementation class for CANCEL Trade action. This class is responsible for Cancelling any 
	trade event with the same event ID. 

4) package: com.jpmc.position.factory
	Class1: TradeActionFactory
	Description: Factory class responsible for producing Trade Action object based on Trade action passed.
	
5) 	package: com.jpmc.position.book
	Class1: BookKeeper
	Description: This class responsible to maintain Positions identified by Account Id and Security ID. 
	It holds Position data in memory using Hashmap collection.
	
6) package: com.jpmc.position.model
	Class1: Account
	Description: Domain class to hold Account details.
	
	Class2: Position
	Description: Domain class to hold Current position and Trade list based on Account Id and Security ID.
	
	Class3: Security
	Description: Domain class to hold Security details.
	
	Class4: Trade
	Description: Domain class to hold Trading details.
	
	Enum: TradeActionEnum
	Description: Domain class to hold Trade actions as a Enum type.
	
========================================================================================================

Sample input and output of the Project -

Input String - Added below String in a List :
1 BUY ACC1 SEC1 100
2 BUY ACC1 SEC1 50

Output String - 
ACC1--SEC1--150 [Trade(tradeId=1, actionEnum=BUY, accountId=ACC1, securityId=SEC1, newPosition=100)] 
[Trade(tradeId=2, actionEnum=BUY, accountId=ACC1, securityId=SEC1, newPosition=50)]  
