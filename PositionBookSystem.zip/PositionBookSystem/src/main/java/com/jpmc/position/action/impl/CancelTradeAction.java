package com.jpmc.position.action.impl;

import com.jpmc.position.action.TradeAction;
import com.jpmc.position.book.BookKeeper;
import com.jpmc.position.model.Position;
import com.jpmc.position.model.Trade;
import com.jpmc.position.model.TradeActionEnum;

public class CancelTradeAction implements TradeAction {

	private BookKeeper keeper;

	public CancelTradeAction(BookKeeper bookKeeper) {
		this.keeper = bookKeeper;
	}

	@Override
	public void process(Trade trade) {

		Position position = keeper.getCurrentPosition(trade);

		Trade cancelledTrade = position.getTradeList().stream().filter(t -> t.getTradeId().equals(trade.getTradeId()))
				.findFirst().get();

		position.getTradeList().add(trade);
		position.getAccount().setAccountId(trade.getAccountId());
		position.getSecurity().setSecurityId(trade.getSecurityId());

		if (cancelledTrade.getTradeAction() == TradeActionEnum.BUY) {
			position.setCurrentPosition(position.getCurrentPosition().subtract(cancelledTrade.getNewPosition()));
		} else {
			position.setCurrentPosition(position.getCurrentPosition().add(cancelledTrade.getNewPosition()));
		}

		keeper.updateBook(position);

	}

}
