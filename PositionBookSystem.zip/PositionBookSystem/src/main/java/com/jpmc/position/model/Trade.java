package com.jpmc.position.model;

import java.math.BigInteger;

import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@EqualsAndHashCode
@ToString
public class Trade {

	private String tradeId;
	private TradeActionEnum tradeAction;
	private String accountId;
	private String securityId;	
	private BigInteger newPosition;
	//sample Trade = "1 BUY ACC1 SEC1 100"
}