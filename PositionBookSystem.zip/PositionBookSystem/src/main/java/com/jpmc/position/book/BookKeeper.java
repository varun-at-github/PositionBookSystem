package com.jpmc.position.book;

import java.util.HashMap;
import java.util.Map;

import com.jpmc.position.model.Position;
import com.jpmc.position.model.Trade;

import lombok.AllArgsConstructor;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

public class BookKeeper {
	
	private Map<PositionKey,Position> book = new HashMap<PositionKey, Position>();
	
	public void updateBook(Position position) {
		book.put(getKey(position.getAccount().getAccountId(), position.getSecurity().getSecurityId()), position);
	}
	
	public Position getCurrentPosition(Trade trade) {
		return book.get(getKey(trade.getAccountId(),trade.getSecurityId()));
	}
		
	public void printBook() {
		book.values().forEach(System.out::println);
	}
	
	private PositionKey getKey(String accountId, String securityId) {
		return new PositionKey(accountId, securityId);
		
	}
	
	@AllArgsConstructor
	@EqualsAndHashCode
	@Getter
	@Setter
	private static class PositionKey {
		
		private String accountId;
		private String securityId;
		
	}

}
