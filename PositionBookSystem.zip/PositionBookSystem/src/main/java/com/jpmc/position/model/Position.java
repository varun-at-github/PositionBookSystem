package com.jpmc.position.model;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;

import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@EqualsAndHashCode
@NoArgsConstructor
public class Position {

	private List<Trade> tradeList = new ArrayList<>();
	private Account account = new Account();
	private Security security = new Security();
	private BigInteger currentPosition = BigInteger.ZERO;
	
	
	public String toString() {
		String positionStr = account.getAccountId() + "--" + security.getSecurityId() + "--" + currentPosition.toString();
		String trades = " ";
		for (Trade s : tradeList) {
			trades = trades + "[" + s.toString() + "] \n";
		}
		return positionStr + trades;
	}
	
}
