package com.jpmc.position.manager;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang3.StringUtils;

import com.jpmc.position.action.TradeAction;
import com.jpmc.position.book.BookKeeper;
import com.jpmc.position.factory.TradeActionFactory;
import com.jpmc.position.model.Trade;
import com.jpmc.position.model.TradeActionEnum;

public class PositionManager {
	
	private BookKeeper keeper;
	
	private List<Trade> badTrades = new ArrayList<Trade>();
	
	public PositionManager(BookKeeper bookkeeper) {
		this.keeper = bookkeeper;
	}
	
	public void processTradeAndUpdateBook(List<String> trades) {
		trades.stream().map(tradeString -> mapStringToTradeObject(tradeString))
		                     .filter(trade -> validateTrade(trade))
		                     .forEach(trade -> processTrade(trade, keeper));		
		keeper.printBook();		
	}
	
	private void processTrade(Trade trade, BookKeeper keeper) {
		TradeAction tradeActionProcessor = TradeActionFactory.getTradeAction(trade.getTradeAction(), keeper);
		tradeActionProcessor.process(trade);
	}

	private Trade mapStringToTradeObject(String tradeString) {
		String[] splitted = StringUtils.split(tradeString);
		Trade trade = new Trade();
		trade.setTradeId(splitted[0]);
		trade.setTradeAction(TradeActionEnum.valueOf(splitted[1]));
		trade.setAccountId(splitted[2]);		
		trade.setSecurityId(splitted[3]);
		trade.setNewPosition(new BigInteger(splitted[4]));
		return trade;
	}
	
	private boolean validateTrade(Trade trade) {
		if(StringUtils.isBlank(trade.getAccountId()) 
				|| StringUtils.isBlank(trade.getSecurityId())
				|| StringUtils.isBlank(trade.getTradeId())) {
			badTrades.add(trade);
		}
		return true;
	}
	

	public static void main(String[] str) {
		
		//List<String> trades = Files.readString(null).lines().collect(Collectors.toList());
		
		List<String> trades = new ArrayList<String>();
		
//		//Example 1: buying securities
//		trads.add("1 BUY ACC1 SEC1 100");
//		trads.add("2 BUY ACC1 SEC1 50");
//		
//		//Example 2: buying different securities
//		trads.add("3 BUY ACC1 SEC2 12");
//		trads.add("4 BUY ACC1 SECXYZ 50");
//		trads.add("5 BUY ACC2 SECXYZ 33");
//		trads.add("6 BUY ACC1 SEC2 20");
//		
//		//Example 3: buying and selling securities
//		trads.add("10 BUY ACC1 SEC3 100");
//		trads.add("11 SELL ACC1 SEC3 50");
		
		//Example 4: Cancelling events
		trades.add("21 BUY ACC1 SEC4 100");
		trades.add("21 CANCEL ACC1 SEC4 0");
		trades.add("22 BUY ACC1 SEC4 5");
		
		//Example 5: Cancelling events - Scenario2
//		trads.add("23 BUY ACC1 SEC5 100");
//		trads.add("24 SELL ACC1 SEC5 50");
//		trads.add("24 CANCEL ACC1 SEC5 0");
//		trads.add("25 BUY ACC1 SEC5 10");
		
		BookKeeper keeper = new BookKeeper();
		PositionManager manager = new PositionManager(keeper);
		
		manager.processTradeAndUpdateBook(trades);
	}

}

