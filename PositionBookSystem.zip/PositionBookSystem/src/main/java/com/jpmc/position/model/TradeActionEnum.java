package com.jpmc.position.model;

public enum TradeActionEnum {
	
	BUY,
	SELL,
	CANCEL

}
