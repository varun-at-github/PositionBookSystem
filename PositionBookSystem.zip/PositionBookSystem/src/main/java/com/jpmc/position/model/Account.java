package com.jpmc.position.model;

import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@EqualsAndHashCode
public class Account {

	private String accountId;
	private String accountHolderName;
	
}
