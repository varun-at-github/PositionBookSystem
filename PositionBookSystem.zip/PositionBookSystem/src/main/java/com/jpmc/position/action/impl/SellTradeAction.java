package com.jpmc.position.action.impl;

import com.jpmc.position.action.TradeAction;
import com.jpmc.position.book.BookKeeper;
import com.jpmc.position.model.Position;
import com.jpmc.position.model.Trade;

public class SellTradeAction implements TradeAction {

	private BookKeeper keeper;

	public SellTradeAction(BookKeeper bookKeeper) {
		this.keeper = bookKeeper;
	}

	@Override
	public void process(Trade trade) {

		Position position = keeper.getCurrentPosition(trade);

		if (position == null) {
			position = new Position();
		}

		position.getTradeList().add(trade);
		position.setCurrentPosition(position.getCurrentPosition().subtract(trade.getNewPosition()));
		position.getAccount().setAccountId(trade.getAccountId());
		position.getSecurity().setSecurityId(trade.getSecurityId());
		keeper.updateBook(position);

	}

}
