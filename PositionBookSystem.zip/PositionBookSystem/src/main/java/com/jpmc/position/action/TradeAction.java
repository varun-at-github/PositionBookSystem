package com.jpmc.position.action;

import com.jpmc.position.model.Trade;

public interface TradeAction {

	void process(Trade trade);
}
