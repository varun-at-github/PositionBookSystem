package com.jpmc.position.factory;

import com.jpmc.position.action.TradeAction;
import com.jpmc.position.action.impl.BuyTradeAction;
import com.jpmc.position.action.impl.CancelTradeAction;
import com.jpmc.position.action.impl.SellTradeAction;
import com.jpmc.position.book.BookKeeper;
import com.jpmc.position.model.TradeActionEnum;

public class TradeActionFactory {
	
	public static TradeAction getTradeAction(TradeActionEnum action, BookKeeper keeper) {
		
		if(action == TradeActionEnum.BUY) {
			return new BuyTradeAction(keeper);
		} else if (action == TradeActionEnum.SELL) {
			return new SellTradeAction(keeper);
		} else if (action == TradeActionEnum.CANCEL) {
			return new CancelTradeAction(keeper);
		} else 
			throw new IllegalArgumentException("Invalid action type");
		
	}

}
