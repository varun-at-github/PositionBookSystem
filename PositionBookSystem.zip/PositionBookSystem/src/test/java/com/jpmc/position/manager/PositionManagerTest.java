package com.jpmc.position.manager;

import static org.hamcrest.CoreMatchers.containsString;
import static org.junit.Assert.assertThat;

import java.io.ByteArrayOutputStream;
import java.io.PrintStream;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.jpmc.position.book.BookKeeper;
import com.jpmc.position.model.Trade;

public class PositionManagerTest {
	
	private static String testBookBuyString = "ACC1--SEC1--200";
	private static String testBookSellString = "ACC2--SEC1--50";
	private static String testBookCancelString = "ACC3--SEC1--0";
	
	private final PrintStream standardOut = System.out;
	private final ByteArrayOutputStream outputStreamCaptor = new ByteArrayOutputStream();
	
	BookKeeper mockKeeper;
	
	Trade mockTrade;
	
	PositionManager mockPositionManager;
	
	List<String> trades;
	
	@Before
	public void setup() {		
		System.setOut(new PrintStream(outputStreamCaptor));
	}

	@Test
	public void testProcessBuyTradeAndUpdateBook() {
		trades = new ArrayList<String>();
		trades.add("1 BUY ACC1 SEC1 150");
		trades.add("2 BUY ACC1 SEC1 50");
		mockKeeper = new BookKeeper();
		mockPositionManager = new PositionManager(mockKeeper);
		mockPositionManager.processTradeAndUpdateBook(trades);
		assertThat(outputStreamCaptor.toString(), containsString(testBookBuyString));
	}
	
	@Test
	public void testProcessSellTradeAndUpdateBook() {
		trades = new ArrayList<String>();
		trades.add("1 BUY ACC2 SEC1 100");
		trades.add("2 SELL ACC2 SEC1 50");
		mockKeeper = new BookKeeper();
		mockPositionManager = new PositionManager(mockKeeper);
		mockPositionManager.processTradeAndUpdateBook(trades);
		assertThat(outputStreamCaptor.toString(), containsString(testBookSellString));
	}
	
	@Test
	public void testProcessCancelTradeAndUpdateBook() {
		trades = new ArrayList<String>();
		trades.add("1 BUY ACC3 SEC1 100");
		trades.add("1 CANCEL ACC3 SEC1 0");
		mockKeeper = new BookKeeper();
		mockPositionManager = new PositionManager(mockKeeper);
		mockPositionManager.processTradeAndUpdateBook(trades);
		assertThat(outputStreamCaptor.toString(), containsString(testBookCancelString));
	}
	
	@After
	public void tearDown() {
	    System.setOut(standardOut);
	}

}
