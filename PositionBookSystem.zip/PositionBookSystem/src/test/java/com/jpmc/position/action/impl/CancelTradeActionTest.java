package com.jpmc.position.action.impl;

import static org.junit.Assert.assertEquals;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Test;

import com.jpmc.position.book.BookKeeper;
import com.jpmc.position.model.Account;
import com.jpmc.position.model.Position;
import com.jpmc.position.model.Security;
import com.jpmc.position.model.Trade;
import com.jpmc.position.model.TradeActionEnum;

public class CancelTradeActionTest {

	BookKeeper mockKeeper;
	
	Position mockPosition;

	CancelTradeAction mockCancelTradeAction;

	Trade mockTrade1, mockTrade2;
	
	Account mockAccountTest;
	
	Security mockSecurityTest;
	

	@Before
	public void setUp() {
		
		mockTrade1 = new Trade();
		mockTrade1.setTradeId("1");
		mockTrade1.setTradeAction(TradeActionEnum.BUY);
		mockTrade1.setAccountId("ACC1");
		mockTrade1.setSecurityId("SEC1");
		mockTrade1.setNewPosition(new BigInteger("100"));
		
		mockPosition = new Position();		
		List<Trade> tradeList = new ArrayList<>();
		tradeList.add(mockTrade1);
		mockPosition.setTradeList(tradeList);
		
		mockAccountTest = new Account();
		mockAccountTest.setAccountId("ACC1");
		
		mockSecurityTest = new Security();		
		mockSecurityTest.setSecurityId("SEC1");
		
		mockPosition.setAccount(mockAccountTest);
		mockPosition.setSecurity(mockSecurityTest);
		mockPosition.setCurrentPosition(mockTrade1.getNewPosition());
		
		mockTrade2 = new Trade();
		mockTrade2.setTradeId("1");
		mockTrade2.setTradeAction(TradeActionEnum.CANCEL);
		mockTrade2.setAccountId("ACC1");
		mockTrade2.setSecurityId("SEC1");
		mockTrade2.setNewPosition(new BigInteger("0"));
	}

	@Test
	public void testCancelTradeProcess() {
		mockKeeper = new BookKeeper();
		mockKeeper.updateBook(mockPosition);
		mockCancelTradeAction = new CancelTradeAction(mockKeeper);
		mockCancelTradeAction.process(mockTrade2);		
		assertEquals("ACC1", mockKeeper.getCurrentPosition(mockTrade2).getAccount().getAccountId());
		assertEquals("SEC1", mockKeeper.getCurrentPosition(mockTrade2).getSecurity().getSecurityId());
		assertEquals(BigInteger.ZERO, mockKeeper.getCurrentPosition(mockTrade2).getCurrentPosition());
	}

}
