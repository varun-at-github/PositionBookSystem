package com.jpmc.position.action.impl;

import static org.junit.Assert.assertEquals;

import java.math.BigInteger;

import org.junit.Before;
import org.junit.Test;

import com.jpmc.position.book.BookKeeper;
import com.jpmc.position.model.Trade;
import com.jpmc.position.model.TradeActionEnum;

public class BuyTradeActionTest {

	BookKeeper keeper;

	BuyTradeAction buyTradeAction;

	Trade trade;

	@Before
	public void setUp() {
		trade = new Trade();
		trade.setTradeId("1");
		trade.setTradeAction(TradeActionEnum.BUY);
		trade.setAccountId("ACC1");
		trade.setSecurityId("SEC1");
		trade.setNewPosition(new BigInteger("100"));
	}

	@Test
	public void testBuyTradeProcess() {
		keeper = new BookKeeper();
		buyTradeAction = new BuyTradeAction(keeper);
		buyTradeAction.process(trade);
		assertEquals("ACC1", keeper.getCurrentPosition(trade).getAccount().getAccountId());
		assertEquals("SEC1", keeper.getCurrentPosition(trade).getSecurity().getSecurityId());
		assertEquals("BUY", keeper.getCurrentPosition(trade).getTradeList().get(0).getTradeAction().toString());
	}

}
