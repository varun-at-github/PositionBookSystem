package com.jpmc.position.action.impl;

import static org.junit.Assert.assertEquals;

import java.math.BigInteger;

import org.junit.Before;
import org.junit.Test;

import com.jpmc.position.book.BookKeeper;
import com.jpmc.position.model.Trade;
import com.jpmc.position.model.TradeActionEnum;

public class SellTradeActionTest {

	BookKeeper mockKeeper;

	SellTradeAction mockSellTradeAction;

	Trade mockTrade;

	@Before
	public void setUp() {
		mockTrade = new Trade();
		mockTrade.setTradeId("1");
		mockTrade.setTradeAction(TradeActionEnum.SELL);
		mockTrade.setAccountId("ACC2");
		mockTrade.setSecurityId("SEC2");
		mockTrade.setNewPosition(new BigInteger("50"));
	}

	@Test
	public void testSellTradeProcess() {
		mockKeeper = new BookKeeper();
		mockSellTradeAction = new SellTradeAction(mockKeeper);
		mockSellTradeAction.process(mockTrade);
		assertEquals("ACC2", mockKeeper.getCurrentPosition(mockTrade).getAccount().getAccountId());
		assertEquals("SEC2", mockKeeper.getCurrentPosition(mockTrade).getSecurity().getSecurityId());
		assertEquals("SELL", mockKeeper.getCurrentPosition(mockTrade).getTradeList().get(0).getTradeAction().toString());
	}

}
