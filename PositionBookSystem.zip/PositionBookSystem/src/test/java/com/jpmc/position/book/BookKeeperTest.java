package com.jpmc.position.book;

import static org.hamcrest.CoreMatchers.containsString;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertThat;

import java.io.ByteArrayOutputStream;
import java.io.PrintStream;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.jpmc.position.model.Account;
import com.jpmc.position.model.Position;
import com.jpmc.position.model.Security;
import com.jpmc.position.model.Trade;
import com.jpmc.position.model.TradeActionEnum;

public class BookKeeperTest {
	
	private static String testBookString = "ACC1--SEC1--100";
	
	private final PrintStream standardOut = System.out;
	private final ByteArrayOutputStream outputStreamCaptor = new ByteArrayOutputStream();

	BookKeeper mockKeeper;
	
	Position mockPosition;
	
	Trade mockTrade;
	
	Account mockAccountTest;
	
	Security mockSecurityTest;	
	
	@Before
	public void setUp() {
		mockTrade = new Trade();
		mockTrade.setTradeId("1");
		mockTrade.setTradeAction(TradeActionEnum.BUY);
		mockTrade.setAccountId("ACC1");
		mockTrade.setSecurityId("SEC1");
		mockTrade.setNewPosition(new BigInteger("100"));
		
		mockPosition = new Position();		
		List<Trade> tradeList = new ArrayList<>();
		tradeList.add(mockTrade);
		mockPosition.setTradeList(tradeList);
		
		mockAccountTest = new Account();
		mockAccountTest.setAccountId("ACC1");
		
		mockSecurityTest = new Security();		
		mockSecurityTest.setSecurityId("SEC1");
		
		mockPosition.setAccount(mockAccountTest);
		mockPosition.setSecurity(mockSecurityTest);
		mockPosition.setCurrentPosition(mockTrade.getNewPosition());
		
		System.setOut(new PrintStream(outputStreamCaptor));
		
	}

	@Test
	public void testUpdateBook() {
		mockKeeper = new BookKeeper();		
		mockKeeper.updateBook(mockPosition);
		mockKeeper.printBook();
		assertThat(outputStreamCaptor.toString(), containsString(testBookString));		
	}
	
	@Test
	public void testGetCurrentPosition() {
		mockKeeper = new BookKeeper();		
		mockKeeper.updateBook(mockPosition);
		assertEquals(mockPosition.getCurrentPosition(), mockKeeper.getCurrentPosition(mockTrade).getCurrentPosition());
	}
	
	@After
	public void tearDown() {
	    System.setOut(standardOut);
	}

}
