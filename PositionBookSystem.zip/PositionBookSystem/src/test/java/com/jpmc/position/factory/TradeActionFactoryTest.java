package com.jpmc.position.factory;

import static org.junit.Assert.assertEquals;

import org.junit.Before;
import org.junit.Test;
import org.mockito.Mock;

import com.jpmc.position.action.impl.BuyTradeAction;
import com.jpmc.position.action.impl.CancelTradeAction;
import com.jpmc.position.action.impl.SellTradeAction;
import com.jpmc.position.book.BookKeeper;
import com.jpmc.position.model.TradeActionEnum;

public class TradeActionFactoryTest {

	@Mock
	TradeActionFactory mockActionFactory;

	@Mock
	BookKeeper mockBookKeeper;

	@Mock
	BuyTradeAction mockBuyTradeAction;

	@Mock
	SellTradeAction mockSellTradeAction;

	@Mock
	CancelTradeAction mockCancelTradeAction;

	@Before
	public void setup() {
		mockActionFactory = new TradeActionFactory();
		mockBookKeeper = new BookKeeper();
	}

	@Test
	public void testGetBuyTradeAction() {
		mockBuyTradeAction = new BuyTradeAction(mockBookKeeper);
		assertEquals(mockBuyTradeAction.getClass(),
				mockActionFactory.getTradeAction(TradeActionEnum.BUY, mockBookKeeper).getClass());
	}

	@Test
	public void testGetSellTradeAction() {
		mockSellTradeAction = new SellTradeAction(mockBookKeeper);
		assertEquals(mockSellTradeAction.getClass(),
				mockActionFactory.getTradeAction(TradeActionEnum.SELL, mockBookKeeper).getClass());
	}

	@Test
	public void testGetCancelTradeAction() {
		mockCancelTradeAction = new CancelTradeAction(mockBookKeeper);
		assertEquals(mockCancelTradeAction.getClass(),
				mockActionFactory.getTradeAction(TradeActionEnum.CANCEL, mockBookKeeper).getClass());
	}

}
